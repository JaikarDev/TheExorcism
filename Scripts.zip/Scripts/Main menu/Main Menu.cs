using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    public GameObject optionsMenu;
    public GameObject creditsMenu;
    public GameObject mainMenu;

    public Dropdown resolutionDropdown;
    public Toggle fullscreenToggle;
    public Slider fpsSlider;
    public Text fpsText;
    public Slider soundSlider;
    public Text soundText;
    public Slider lightSlider;
    public Light sceneLight;

    public AudioSource mainMenuAudioSource;
    public AudioSource creditsAudioSource;
    public AudioClip mainMenuAudioClip;
    public AudioClip creditsAudioClip;

    public Texture2D customCursor;   // Assign custom cursor texture in Inspector
    public Vector2 cursorHotspot = Vector2.zero; // Set cursor click point

    private Resolution[] resolutions;

    private void Start()
    {
        // Show and customize cursor
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        SetCustomCursor();

        // Setup resolutions
        resolutions = Screen.resolutions;
        resolutionDropdown.ClearOptions();

        List<string> options = new List<string>();
        int currentResolutionIndex = 0;

        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + "x" + resolutions[i].height;
            options.Add(option);
            if (resolutions[i].width == Screen.currentResolution.width && resolutions[i].height == Screen.currentResolution.height)
            {
                currentResolutionIndex = i;
            }
        }

        resolutionDropdown.AddOptions(options);
        resolutionDropdown.value = currentResolutionIndex;
        resolutionDropdown.RefreshShownValue();

        fullscreenToggle.isOn = Screen.fullScreen;
        fpsSlider.value = Application.targetFrameRate > 0 ? Application.targetFrameRate : 60;
        fpsText.text = fpsSlider.value.ToString() + " FPS";
        soundSlider.value = AudioListener.volume * 100;
        soundText.text = "Sound: " + soundSlider.value.ToString("F0") + "%";
        lightSlider.value = sceneLight.intensity;

        // Set initial music
        mainMenuAudioSource.clip = mainMenuAudioClip;
        creditsAudioSource.clip = creditsAudioClip;

        PlayMainMenuMusic();

        // Add listener to the sound slider
        soundSlider.onValueChanged.AddListener(SetSound);
    }

    // Methods for menu navigation
    public void PlayGame()
    {
        Cursor.visible = false;  // Hide cursor when starting game
        SceneManager.LoadScene("Intro Video");
    }

    public void ShowOptions()
    {
        mainMenu.SetActive(false);
        optionsMenu.SetActive(true);
    }

    public void ShowCredits()
    {
        mainMenu.SetActive(false);
        creditsMenu.SetActive(true);
    }

    public void BackToMainMenu()
    {
        optionsMenu.SetActive(false);
        creditsMenu.SetActive(false);
        mainMenu.SetActive(true);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    // Methods to update settings
    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
    }

    public void SetFullScreen(bool isFullscreen)
    {
        Screen.fullScreen = isFullscreen;
    }

    public void SetFPS(float fps)
    {
        Application.targetFrameRate = (int)fps;
        fpsText.text = fps + " FPS";
    }

    public void SetLightIntensity(float intensity)
    {
        sceneLight.intensity = intensity;
    }

    // Play music for the Main Menu/Options
    private void PlayMainMenuMusic()
    {
        if (creditsAudioSource.isPlaying)
            creditsAudioSource.Stop();

        if (!mainMenuAudioSource.isPlaying)
            mainMenuAudioSource.Play();
    }

    // Play music for Credits
    private void PlayCreditsMusic()
    {
        if (mainMenuAudioSource.isPlaying)
            mainMenuAudioSource.Stop();

        if (!creditsAudioSource.isPlaying)
            creditsAudioSource.Play();
    }

    // Method to update sound volume based on the slider
    public void SetSound(float volume)
    {
        // Convert volume from slider (0-100) to 0-1 range and apply to AudioListener
        AudioListener.volume = volume / 100;

        // Update the volume of the music based on the new volume level
        if (mainMenuAudioSource.isPlaying)
        {
            mainMenuAudioSource.volume = AudioListener.volume;
        }

        if (creditsAudioSource.isPlaying)
        {
            creditsAudioSource.volume = AudioListener.volume;
        }

        // Update sound text to show the current sound level
        soundText.text = "Sound: " + volume.ToString("F0") + "%";
    }

    // Custom Cursor Method
    private void SetCustomCursor()
    {
        if (customCursor != null)
        {
            try
            {
                Cursor.SetCursor(customCursor, cursorHotspot, CursorMode.Auto);
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("Failed to set custom cursor: " + e.Message);
            }
        }
    }
}

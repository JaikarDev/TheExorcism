using UnityEngine;

public class TriggerInsideHouse : MonoBehaviour
{
    public MainDoor mainDoorScript; // Reference to the MainDoor script

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player entered the house. Locking the main door.");

            if (mainDoorScript != null)
            {
                mainDoorScript.SetPlayerEntered(true); // Mark player as entered
            }
        }
    }
}
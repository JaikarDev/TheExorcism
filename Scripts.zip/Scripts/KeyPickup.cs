using UnityEngine;

public class KeyPickup : MonoBehaviour
{
    public string keyName; // Name of the key, e.g., "RedKey", "GreenKey", "DarkRedKey"
    public AudioSource pickupSound; // Optional sound effect for picking up the key
    public DoorController associatedDoor; // The door this key unlocks

    private bool isCollected = false; // Track if the key has already been collected

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !isCollected)
        {
            CollectKey();
        }
    }

    private void CollectKey()
    {
        isCollected = true;

        // Unlock the associated door
        if (associatedDoor != null)
        {
            associatedDoor.CollectKey(); // Unlocks the door
            Debug.Log($"{keyName} collected! {associatedDoor.name} is now unlocked.");
        }

        // Play pickup sound if available
        if (pickupSound != null)
        {
            pickupSound.Play();
        }

        // Optionally, destroy the key object after pickup
        Destroy(gameObject);
    }
}

using UnityEngine;
using UnityEngine.UI;

public class MatchboxController : MonoBehaviour
{
    public int matchstickCount = 2; // Start with 2 matchsticks
    public int matchsticksPerBox = 6; // Number of matchsticks per matchbox
    public float fireDuration = 30f; // Fire stays for 30 seconds
    public ParticleSystem fireParticles; // Reference to the fire particle system
    public Light fireLight; // Reference to fire light
    public AudioClip matchStrikeSound; // Sound for striking a match
    private AudioSource audioSource;

    private bool canUseMatchstick = true; // Flag to check if the player can use a matchstick

    void Start()
    {
        fireParticles.Stop(); // Fire particles are off initially
        fireLight.enabled = false; // Light is off initially
        audioSource = GetComponent<AudioSource>();

        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M) && canUseMatchstick) // Press M to use a matchstick
        {
            UseMatchstick();
        }
    }

    public void UseMatchstick()
    {
        if (matchstickCount > 0)
        {
            matchstickCount--; // Reduce matchstick count

            fireParticles.Play(); // Turn on fire particles
            audioSource.PlayOneShot(matchStrikeSound); // Play match strike sound

            // Wait for a short period and then turn on the light once the fire starts
            Invoke("EnableLight", 0.1f); // Small delay to ensure particles have started

            // Disable the ability to use matchstick for fire duration
            canUseMatchstick = false;

            // Turn off fire and light after the fire duration
            Invoke("ExtinguishFire", fireDuration);

            // Reset the ability to use matchsticks after the fire duration
            Invoke("EnableMatchstickUse", fireDuration);
        }
        else
        {
            Debug.Log("No matchsticks left! Find more matchboxes.");
        }
    }

    private void EnableLight()
    {
        if (fireParticles.isPlaying) // Ensure the fire particles are playing
        {
            fireLight.enabled = true; // Turn on the light
        }
    }

    private void ExtinguishFire()
    {
        fireParticles.Stop(); // Turn off the fire particles
        fireLight.enabled = false; // Turn off the light
    }

    private void EnableMatchstickUse()
    {
        canUseMatchstick = true; // Allow the player to use matchsticks again after the fire duration
    }

    public void CollectMatchbox()
    {
        matchstickCount += matchsticksPerBox; // Add more matchsticks
        Debug.Log("Collected a matchbox! Matchsticks: " + matchstickCount);
    }
}

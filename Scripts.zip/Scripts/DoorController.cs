using UnityEngine;
using UnityEngine.UI;

public class DoorController : MonoBehaviour
{
    public Transform doorPivot;
    public float openAngle = 90f;
    public float closeAngle = 0f;
    public float smoothSpeed = 2f;
    public bool isLocked = false;
    public bool requiresKey = false;
    public string doorName; // Identifier for specific doors (e.g., "Red Door", "Green Door", "Dark Red Door")
    public AudioSource doorUnlockSound;
    public AudioSource doorOpenCloseSound;
    public Text interactionPrompt;

    // Special requirements for Dark Red Door
    public bool isDarkRedDoor = false;
    public bool allLettersRead = false;
    public bool audioPlayed = false;
    public bool keyCollected = false;
    public GameObject requiredKey; // The key to unlock
    public AudioSource darkRedAudio;
    public Text infoDisplay; // Info display for letters or messages

    private bool isOpen = false;
    private Quaternion targetRotation;
    private BoxCollider triggerCollider; // Reference to the trigger collider

    void Start()
    {
        targetRotation = Quaternion.Euler(0, closeAngle, 0);
        if (interactionPrompt != null) interactionPrompt.enabled = false;

        // Get the trigger collider
        triggerCollider = GetComponent<BoxCollider>();

        // Disable the trigger for specific doors if they require a key and are locked
        if ((doorName == "Red Door" || doorName == "Green Door" || doorName == "Dark Red Door") && requiresKey && isLocked)
        {
            if (triggerCollider != null)
            {
                triggerCollider.isTrigger = false; // Turn off trigger functionality until key is collected
            }
        }
    }

    void Update()
    {
        doorPivot.rotation = Quaternion.Slerp(doorPivot.rotation, targetRotation, Time.deltaTime * smoothSpeed);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && interactionPrompt != null)
        {
            interactionPrompt.enabled = true;
            if (requiresKey && !keyCollected)
                interactionPrompt.text = "You need a key to unlock this door!";
            else if (isDarkRedDoor && (!allLettersRead || !audioPlayed || !keyCollected))
                interactionPrompt.text = "Complete all tasks to unlock this door!";
            else
                interactionPrompt.text = "Press 'E' to interact.";
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && Input.GetKeyDown(KeyCode.E))
        {
            if (requiresKey && !keyCollected)
            {
                Debug.Log("The door is locked! Find the key.");
                if (doorUnlockSound != null) doorUnlockSound.Play();
            }
            else if (isDarkRedDoor)
            {
                if (!allLettersRead || !audioPlayed || !keyCollected)
                {
                    Debug.Log("Complete all tasks for the dark red door!");
                    return;
                }
                else
                {
                    ToggleDoor();
                }
            }
            else
            {
                ToggleDoor();
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player") && interactionPrompt != null)
        {
            interactionPrompt.enabled = false;
        }
    }

    private void ToggleDoor()
    {
        isOpen = !isOpen;
        targetRotation = Quaternion.Euler(0, isOpen ? openAngle : closeAngle, 0);

        if (doorOpenCloseSound != null)
            doorOpenCloseSound.Play();
    }

    public void CollectKey()
    {
        keyCollected = true;
        isLocked = false; // Unlock the door

        // Enable the trigger functionality for specific doors
        if ((doorName == "Red Door" || doorName == "Green Door" || doorName == "Dark Red Door") && triggerCollider != null)
        {
            triggerCollider.isTrigger = true; // Turn on trigger functionality when key is collected
        }

        Debug.Log("Key collected! Door is now unlocked.");
        if (interactionPrompt != null)
            interactionPrompt.text = "Key collected! You can now unlock the door.";
    }

    public void ReadLetter()
    {
        Debug.Log("Letter read!");
        // Track progress for letters
        if (infoDisplay != null)
            infoDisplay.text = "Letter read! Find all letters.";
    }

    public void PlayAudio()
    {
        if (darkRedAudio != null)
        {
            darkRedAudio.Play();
            audioPlayed = true;
            Debug.Log("Audio played!");
        }
    }

    public void UnlockDarkRedDoor()
    {
        allLettersRead = true;
        audioPlayed = true;
        keyCollected = true;

        // Enable the trigger functionality for Dark Red Door
        if (triggerCollider != null)
        {
            triggerCollider.isTrigger = true;
        }

        Debug.Log("Dark red door is ready to unlock!");
    }
}

using System.Collections; // For coroutines
using UnityEngine;
using UnityEngine.UI;

public class LetterInteraction : MonoBehaviour
{
    public GameObject letterCanvas; // UI for reading the letter
    public Image letterImage; // Image component to display the letter
    public Text letterText; // Text component for the letter story
    public Sprite letterSprite; // Sprite for the letter image
    [TextArea(5, 10)] public string storyText; // Content of the letter

    public GameObject interactionPopup; // The 'E' key prompt for interaction
    public AudioSource letterAudio; // Audio playback for Letter 1
    public AudioSource strangeSoundsAudio; // Eerie sound
    public AudioSource clapAudio; // Clap sound
    public Light[] houseLights; // All lights in the house
    public Camera mainCamera; // Player's main camera
    public Transform windowLookAtPoint; // Position where devil appears
    public GameObject devilCharacter; // Devil object to appear in the reveal
    public float delayBeforeClap = 2f; // Delay before clap sound
    public float delayBeforeReveal = 2f; // Delay before camera pans to window

    private bool isPlayerNearby = false; // Tracks if the player is near
    private bool isReadingLetter = false; // Tracks if the player is reading the letter
    private bool hasStartedScareSequence = false; // Ensures scare runs only once
    private bool lightsTurnedOff = false; // Ensures lights remain off until interaction
    private Vector3 originalCameraPosition; // For resetting camera position
    private Quaternion originalCameraRotation; // For resetting camera rotation
    private PlayerMovement playerMovement; // Reference to the player's movement script

    public QuestManager questManager; // Reference to the quest manager

    private void Start()
    {
        if (interactionPopup != null) interactionPopup.SetActive(false);
        if (devilCharacter != null) devilCharacter.SetActive(false);
        playerMovement = FindObjectOfType<PlayerMovement>();
        questManager = FindObjectOfType<QuestManager>(); // Find the quest manager in the scene

        if (playerMovement == null)
        {
            Debug.LogError("PlayerMovement script not found on the player!");
        }
    }

    private void Update()
    {
        if (isPlayerNearby && Input.GetKeyDown(KeyCode.E) && !isReadingLetter)
        {
            LockPlayer();
            ShowLetter();
            isReadingLetter = true; // Mark as reading the letter
        }
        else if (isReadingLetter && Input.GetKeyDown(KeyCode.E))
        {
            HideLetter();
            UnlockPlayer();
            isReadingLetter = false; // Mark as not reading anymore

            if (!hasStartedScareSequence) // Start scare only after letter is hidden
            {
                hasStartedScareSequence = true;
                StartScareSequence();
            }

            // Update quest to find remaining letters and keys
            if (questManager != null)
            {
                questManager.UpdateQuest("Find the remaining letters and keys");
            }
        }
    }

    private void ShowLetter()
    {
        letterCanvas.SetActive(true);
        letterImage.sprite = letterSprite;
        letterText.text = storyText;
        if (letterAudio != null && !letterAudio.isPlaying)
        {
            letterAudio.Play();
        }
    }

    private void HideLetter()
    {
        letterCanvas.SetActive(false);
        if (letterAudio != null && letterAudio.isPlaying)
        {
            letterAudio.Stop();
        }

        // Trigger the devil's jump scare
        DevilAI devilAI = FindObjectOfType<DevilAI>();
        if (devilAI != null)
        {
            devilAI.TriggerJumpScare();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = true;
            if (interactionPopup != null) interactionPopup.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = false;
            if (interactionPopup != null) interactionPopup.SetActive(false);
        }
    }

    private void StartScareSequence()
    {
        StartCoroutine(ScareSequenceRoutine());
    }

    private IEnumerator ScareSequenceRoutine()
    {
        if (strangeSoundsAudio != null)
        {
            strangeSoundsAudio.Play();
        }
        yield return new WaitForSeconds(delayBeforeClap);

        if (clapAudio != null)
        {
            clapAudio.Play();
        }
        ToggleLights(false); // Turn off lights
        lightsTurnedOff = true; // Ensure lights stay off until clap interaction
        yield return new WaitForSeconds(delayBeforeReveal);

        RevealOutsideWatcher();
    }

    private void ToggleLights(bool state)
    {
        if (!lightsTurnedOff || state) // Prevent auto-turning on before clap
        {
            foreach (Light light in houseLights)
            {
                light.enabled = state;
            }
        }
    }

    private void RevealOutsideWatcher()
    {
        originalCameraPosition = mainCamera.transform.position;
        originalCameraRotation = mainCamera.transform.rotation;
        mainCamera.transform.LookAt(windowLookAtPoint);
        if (devilCharacter != null)
        {
            devilCharacter.SetActive(true);
        }
        StartCoroutine(ResetCameraRoutine());
    }

    private IEnumerator ResetCameraRoutine()
    {
        yield return new WaitForSeconds(3f);
        mainCamera.transform.position = originalCameraPosition;
        mainCamera.transform.rotation = originalCameraRotation;
        if (devilCharacter != null)
        {
            devilCharacter.SetActive(false);
        }
    }

    private void LockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.LockMovement();
        }
    }

    private void UnlockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.UnlockMovement();
        }
    }
}

using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Letter3Interaction : MonoBehaviour
{
    public GameObject letterCanvas; // UI for reading the letter
    public Image letterImage; // Image component to display the letter
    public Text letterText; // Text component for the letter story
    public Sprite letterSprite; // Sprite for the letter image
    [TextArea(5, 10)] public string storyText; // Content of the letter

    public GameObject interactionPopup; // The 'E' key prompt for interaction
    public AudioSource letterAudio; // Audio playback for Letter 3
    public AudioSource eerieWhisperAudio; // Whispering sound effect
    public AudioSource doorCreekAudio; // Door creaking sound effect
    public Light[] houseLights; // All lights in the house
    public Camera mainCamera; // Player's main camera
    public Transform mirrorLookAtPoint; // Position of the mirror reveal
    public GameObject redDoorKey; // Reference to the key for the Red Door
    public GameObject devilCharacter; // Devil object to appear in the reveal
    public float delayBeforeWhisper = 1.5f; // Delay before whisper sound
    public float delayBeforeReveal = 2f; // Delay before camera pans to mirror

    private bool isPlayerNearby = false; // Tracks if the player is near
    private bool isReadingLetter = false; // Tracks if the player is reading the letter
    private bool hasStartedScareSequence = false; // Ensures scare runs only once
    private Vector3 originalCameraPosition; // For resetting camera position
    private Quaternion originalCameraRotation; // For resetting camera rotation
    private PlayerMovement playerMovement; // Reference to the PlayerMovement script
    private bool areLightsOff = false; // Tracks whether the lights have been turned off

    private void Start()
    {
        if (interactionPopup != null) interactionPopup.SetActive(false);
        if (devilCharacter != null) devilCharacter.SetActive(false);

        // Hide the Red Door Key initially
        if (redDoorKey != null)
        {
            redDoorKey.SetActive(false); // The key will only appear after reading the letter
        }

        // Get reference to the player's movement script
        playerMovement = FindObjectOfType<PlayerMovement>();
        if (playerMovement == null)
        {
            Debug.LogError("PlayerMovement script not found on the player!");
        }
    }

    private void Update()
    {
        if (isPlayerNearby && Input.GetKeyDown(KeyCode.E) && !isReadingLetter)
        {
            LockPlayer(); // Lock the player's movement
            ShowLetter();
            isReadingLetter = true; // Mark as reading the letter
        }
        else if (isReadingLetter && Input.GetKeyDown(KeyCode.E))
        {
            HideLetter();
            UnlockPlayer(); // Unlock the player's movement
            isReadingLetter = false; // Mark as not reading the letter anymore

            if (!hasStartedScareSequence)
            {
                hasStartedScareSequence = true;
                StartScareSequence();
            }
        }
    }

    private void ShowLetter()
    {
        letterCanvas.SetActive(true);
        letterImage.sprite = letterSprite;
        letterText.text = storyText;
        if (letterAudio != null && !letterAudio.isPlaying)
        {
            letterAudio.Play();
        }
    }

    private void HideLetter()
    {
        letterCanvas.SetActive(false);
        if (letterAudio != null && letterAudio.isPlaying)
        {
            letterAudio.Stop();
        }
        // Trigger the devil's jump scare
        DevilAI devilAI = FindObjectOfType<DevilAI>();
        if (devilAI != null)
        {
            devilAI.TriggerJumpScare();
        }
        // Now reveal the key only after closing the letter
        if (redDoorKey != null && !redDoorKey.activeSelf)
        {
            redDoorKey.SetActive(true);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = true;
            if (interactionPopup != null) interactionPopup.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = false;
            if (interactionPopup != null) interactionPopup.SetActive(false);
        }
    }

    private void StartScareSequence()
    {
        StartCoroutine(ScareSequenceRoutine());
    }

    private IEnumerator ScareSequenceRoutine()
    {
        if (eerieWhisperAudio != null)
        {
            eerieWhisperAudio.Play();
        }
        yield return new WaitForSeconds(delayBeforeWhisper);

        if (doorCreekAudio != null)
        {
            doorCreekAudio.Play();
        }
        ToggleLights(false); // Turn off lights when scare sequence starts
        yield return new WaitForSeconds(delayBeforeReveal);

        RevealMirror();
    }

    private void ToggleLights(bool state)
    {
        if (state == false && !areLightsOff) // Turn off the lights only once
        {
            foreach (Light light in houseLights)
            {
                light.enabled = state;
            }
            areLightsOff = true; // Mark lights as turned off
        }
    }

    private void RevealMirror()
    {
        originalCameraPosition = mainCamera.transform.position;
        originalCameraRotation = mainCamera.transform.rotation;

        mainCamera.transform.LookAt(mirrorLookAtPoint);

        StartCoroutine(ResetCameraRoutine());
    }

    private IEnumerator ResetCameraRoutine()
    {
        yield return new WaitForSeconds(3f);

        mainCamera.transform.position = originalCameraPosition;
        mainCamera.transform.rotation = originalCameraRotation;

        // Do not toggle lights back on since we've marked them as off in the scare sequence
        // Lights remain off, no further changes to light state here

        // Make the Red Door Key appear
        if (redDoorKey != null)
        {
            redDoorKey.SetActive(true); // The key is now visible after the scare sequence
        }
    }

    private void LockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.LockMovement(); // Disable player movement
        }
    }

    private void UnlockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.UnlockMovement(); // Enable player movement
        }
    }
}

using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using System.Collections;

public class VideoAndAudioInteraction_Letter3 : MonoBehaviour
{
    public GameObject interactionPopup; // UI prompt, e.g., "Press E to interact"
    public VideoPlayer videoPlayer; // Reference to the VideoPlayer component
    public AudioSource audioSource; // Reference to the AudioSource component
    public GameObject videoCanvas; // Canvas to display the video
    public GameObject ritualObject; // Object the player interacts with
    public GameObject devilObject; // The devil that reacts after the video
    public Light[] houseLights; // Lights that flicker
    public Text timerText; // UI Timer text

    public GameObject darkRedDoorKey; // The key for the Dark Red Door
    public GameObject holyWater; // Holy Water object

    public QuestManager questManager; // Reference to QuestManager

    private bool isPlayerNearby = false; // Tracks if the player is near
    private bool hasTriggered = false; // Ensures the sequence runs only once
    private PlayerMovement playerMovement; // Reference to the player's movement script
    private float countdownTime = 10f; // Countdown timer after reaction

    void Start()
    {
        if (interactionPopup != null) interactionPopup.SetActive(false);
        if (videoCanvas != null) videoCanvas.SetActive(false);
        if (devilObject != null) devilObject.SetActive(false); // Hide devil initially
        if (timerText != null) timerText.gameObject.SetActive(false);
        if (darkRedDoorKey != null) darkRedDoorKey.SetActive(false); // Hide key initially
        if (holyWater != null) holyWater.SetActive(false); // Hide holy water initially

        playerMovement = FindObjectOfType<PlayerMovement>();
        if (playerMovement == null)
        {
            Debug.LogError("PlayerMovement script not found on the player!");
        }
    }

    void Update()
    {
        if (isPlayerNearby && Input.GetKeyDown(KeyCode.E) && !hasTriggered)
        {
            hasTriggered = true;
            LockPlayer();
            PlayVideoAndAudio();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = true;
            if (interactionPopup != null) interactionPopup.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = false;
            if (interactionPopup != null) interactionPopup.SetActive(false);
        }
    }

    private void PlayVideoAndAudio()
    {
        if (videoCanvas != null) videoCanvas.SetActive(true);
        if (videoPlayer != null) videoPlayer.Play();
        if (audioSource != null) audioSource.Play();

        StartCoroutine(WaitForVideoEnd());
    }

    private IEnumerator WaitForVideoEnd()
    {
        if (videoPlayer != null)
        {
            while (videoPlayer.isPlaying)
            {
                yield return null;
            }
        }

        Debug.Log("The devil is reacting!");
        if (devilObject != null) devilObject.SetActive(true); // Show the devil

        StartCoroutine(FlickerLights()); // Start light flickering
        StartCoroutine(StartCountdown()); // Start the timer

        yield return new WaitForSeconds(5f); // Delay before showing key & holy water

        if (darkRedDoorKey != null) darkRedDoorKey.SetActive(true);
        if (holyWater != null) holyWater.SetActive(true);

        // Update the quest after the interaction
        if (questManager != null)
        {
            questManager.SetQuest("Now you need to find Holy Water.");
        }

        UnlockPlayer();
    }

    private IEnumerator FlickerLights()
    {
        for (int i = 0; i < 10; i++)
        {
            foreach (Light light in houseLights)
            {
                light.enabled = !light.enabled;
            }
            yield return new WaitForSeconds(0.2f);
        }
    }

    private IEnumerator StartCountdown()
    {
        if (timerText != null)
        {
            timerText.gameObject.SetActive(true);
            while (countdownTime > 0)
            {
                timerText.text = "Time Left: " + countdownTime.ToString("F1") + "s";
                yield return new WaitForSeconds(1f);
                countdownTime -= 1f;
            }
            timerText.gameObject.SetActive(false);
        }
    }

    private void LockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.LockMovement();
        }
    }

    private void UnlockPlayer()
    {
        if (playerMovement != null)
        {
            playerMovement.UnlockMovement();
        }
    }
}

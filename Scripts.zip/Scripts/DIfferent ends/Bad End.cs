using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BadEnd : MonoBehaviour
{
    public VideoPlayer videoPlayer;  // Assign VideoPlayer in Inspector
    public Button retryButton;       // Assign Retry Button in Inspector
    public Button HomeButton;        // Assign Home Button in Inspector
    public Texture2D customCursor;   // Assign custom cursor texture in Inspector
    public Vector2 cursorHotspot = Vector2.zero; // Set cursor click point

    void Start()
    {
        retryButton.gameObject.SetActive(false);
        HomeButton.gameObject.SetActive(false);
        Cursor.visible = false;  // Hide cursor initially
        videoPlayer.loopPointReached += OnVideoEnd;
    }

    void OnVideoEnd(VideoPlayer vp)
    {
        retryButton.gameObject.SetActive(true);
        HomeButton.gameObject.SetActive(true);
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;

        // Apply custom cursor if assigned
        if (customCursor != null)
        {
            try
            {
                Cursor.SetCursor(customCursor, cursorHotspot, CursorMode.Auto);
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("Failed to set custom cursor: " + e.Message);
            }
        }
    }

    public void RetryGame()
    {
        Cursor.visible = false;
        SceneManager.LoadScene("Intro Video");
    }

    public void ReturnToMainMenu()
    {
        Cursor.visible = false;
        SceneManager.LoadScene("Main Menu");
    }
}

using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Nutralend : MonoBehaviour
{
    public VideoPlayer videoPlayer;  // Assign VideoPlayer in Inspector
    public Button retryButton;       // Assign Retry Button in Inspector
    public Button HomeButton;        // Assign Home Button in Inspector
    public Texture2D customCursor;   // Assign your custom cursor texture in Inspector

    void Start()
    {
        retryButton.gameObject.SetActive(false);
        HomeButton.gameObject.SetActive(false);
        Cursor.visible = false;  // Hide the cursor initially
        Cursor.lockState = CursorLockMode.Locked; // Lock cursor to center
        videoPlayer.loopPointReached += OnVideoEnd;
    }

    void OnVideoEnd(VideoPlayer vp)
    {
        retryButton.gameObject.SetActive(true);
        HomeButton.gameObject.SetActive(true);

        // Show the cursor
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;

        // Set a custom cursor
        if (customCursor != null)
        {
            Cursor.SetCursor(customCursor, Vector2.zero, CursorMode.Auto);
        }
    }

    public void RetryGame()
    {
        Cursor.visible = false;  // Hide the cursor when restarting
        Cursor.lockState = CursorLockMode.Locked;
        SceneManager.LoadScene("Intro Video");
    }

    public void ReturnToMainMenu()
    {
        Cursor.visible = false;  // Hide the cursor when returning to the menu
        Cursor.lockState = CursorLockMode.Locked;
        SceneManager.LoadScene("Main Menu");
    }
}

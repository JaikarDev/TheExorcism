using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseMenuUI;   // Pause menu panel
    public GameObject warningPopup;  // Warning popup panel
    public Slider volumeSlider;      // Sound slider
    private bool isPaused = false;

    public AudioSource pauseSound;   // Sound when pausing
    public AudioSource resumeSound;  // Sound when resuming
    public AudioSource buttonClickSound;  // Button click sound
    public AudioSource pauseMenuMusic;  // Background music for pause menu

    public Texture2D customCursor;   // Custom cursor texture

    void Start()
    {
        pauseMenuUI.SetActive(false);
        warningPopup.SetActive(false);
        Time.timeScale = 1f;

        // Hide cursor initially
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        // Set initial volume
        if (volumeSlider != null)
        {
            volumeSlider.value = AudioListener.volume;
            volumeSlider.onValueChanged.AddListener(SetVolume);
        }

        if (pauseMenuMusic != null)
        {
            pauseMenuMusic.loop = true;  // Ensure it loops
            pauseMenuMusic.Stop(); // Don't play at the start
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                ResumeGame();
            else
                PauseGame();
        }
    }

    public void PauseGame()
    {
        if (pauseSound) pauseSound.Play();  // Play pause sound
        if (pauseMenuMusic) pauseMenuMusic.Play();  // Start pause menu music

        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        isPaused = true;
        AudioListener.pause = true;

        // Show and apply custom cursor
        Cursor.SetCursor(customCursor, Vector2.zero, CursorMode.Auto);
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
    }

    public void ResumeGame()
    {
        if (resumeSound) resumeSound.Play();  // Play resume sound
        if (pauseMenuMusic) pauseMenuMusic.Stop();  // Stop pause menu music

        pauseMenuUI.SetActive(false);
        warningPopup.SetActive(false);
        Time.timeScale = 1f;
        isPaused = false;
        AudioListener.pause = false;

        // Hide cursor when resuming game
        Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    public void OpenQuitWarning()
    {
        if (buttonClickSound) buttonClickSound.Play();  // Play button click sound
        warningPopup.SetActive(true);
    }

    public void CloseQuitWarning()
    {
        if (buttonClickSound) buttonClickSound.Play();  // Play button click sound
        warningPopup.SetActive(false);
    }

    public void QuitToMainMenu()
    {
        if (buttonClickSound) buttonClickSound.Play();  // Play button click sound
        Time.timeScale = 1f;
        SceneManager.LoadScene("Main Menu");
    }

    public void SetVolume(float volume)
    {
        AudioListener.volume = volume;
    }
}

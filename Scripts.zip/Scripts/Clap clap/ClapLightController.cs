﻿using System.Collections;
using UnityEngine;

public class ClapLightController : MonoBehaviour
{
    public AudioClip singleClap; // Sound for a single clap
    public AudioClip doubleClap; // Sound for a double clap
    public AudioClip flickerSound; // Flickering sound effect
    public Light roomLight; // Reference to the light being controlled
    public FuseBoxInteraction fuseBox; // Reference to FuseBoxInteraction
    public QuestManager questManager; // Reference to QuestManager
    public Transform playerTransform; // Reference to the player's position
    public float interactionRange = 5f; // Range within which the player can interact with the light

    private AudioSource audioSource;
    private int clapCount = 0;
    private float lastClapTime;
    private float clapThreshold = 0.5f; // Time frame for detecting double claps
    private bool awaitingSecondClap = false;
    private bool lightsActivated = false; // Track if lights have been activated

    void Start()
    {
        audioSource = GetComponent<AudioSource>();

        // Automatically add an AudioSource if missing
        if (audioSource == null)
        {
            Debug.LogWarning("AudioSource component missing. Adding one automatically.");
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Update()
    {
        // Ensure the clap function only works after the fuse box is powered on
        if (fuseBox != null && !fuseBox.GetPowerStatus()) return;

        // Check if the player is within the interaction range of the light
        if (Vector3.Distance(playerTransform.position, roomLight.transform.position) <= interactionRange)
        {
            if (Input.GetKeyDown(KeyCode.C)) // Detect clap with the C key
            {
                float currentTime = Time.time;

                if (currentTime - lastClapTime < clapThreshold)
                {
                    clapCount++;
                }
                else
                {
                    clapCount = 1;
                    awaitingSecondClap = true;
                    StartCoroutine(WaitForSecondClap());
                }

                lastClapTime = currentTime;
            }
        }
    }

    private IEnumerator WaitForSecondClap()
    {
        yield return new WaitForSeconds(clapThreshold);

        if (clapCount == 1)
        {
            // Single clap: Turn light OFF
            audioSource.PlayOneShot(singleClap);
            roomLight.enabled = false;
        }
        else if (clapCount == 2)
        {
            // Double clap: Turn light ON and trigger flickering only if player is near the light
            audioSource.PlayOneShot(doubleClap);

            if (Vector3.Distance(playerTransform.position, roomLight.transform.position) <= interactionRange)
            {
                StartCoroutine(FlickerLights(2f)); // Flicker lights for 2 seconds

                // Update quest when lights turn on for the first time
                if (!lightsActivated && questManager != null)
                {
                    questManager.SetQuest("Power restored! 🎉");
                    lightsActivated = true;
                }
            }
            else
            {
                Debug.Log("Player is too far from the light to turn it on.");
            }
        }

        clapCount = 0; // Reset clap count
        awaitingSecondClap = false;
    }

    private IEnumerator FlickerLights(float duration)
    {
        float elapsedTime = 0f;

        // Play flicker sound
        if (flickerSound != null)
        {
            audioSource.clip = flickerSound;
            audioSource.loop = true;
            audioSource.Play();
        }

        while (elapsedTime < duration)
        {
            // Toggle the light state (ON/OFF)
            roomLight.enabled = !roomLight.enabled;

            // Wait for a short duration before toggling again
            yield return new WaitForSeconds(0.1f); // Adjust flicker speed
            elapsedTime += 0.1f;
        }

        // Stop flicker sound
        if (flickerSound != null && audioSource.isPlaying)
        {
            audioSource.loop = false;
            audioSource.Stop();
        }

        // Ensure the light remains ON after flickering
        roomLight.enabled = true;
    }
}

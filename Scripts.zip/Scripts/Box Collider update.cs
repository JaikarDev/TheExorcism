using UnityEngine;

public class BoxColliderUpdate : MonoBehaviour
{
    public QuestManager questManager; // Reference to QuestManager
    private bool questUpdated = false; // Ensure quest updates only once

    void Start()
    {
        if (questManager == null)
        {
            questManager = FindObjectOfType<QuestManager>(); // Auto-find QuestManager if not set
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !questUpdated) // Ensure only the player triggers it once
        {
            Debug.Log("Player entered the quest zone. Updating quest...");

            if (questManager != null)
            {
                questManager.UpdateQuest("Find the letter in the living room.");
                questUpdated = true; // Mark quest as updated
                GetComponent<Collider>().enabled = false; // Disable this BoxCollider after quest updates
            }
            else
            {
                Debug.LogError("QuestManager not assigned or found!");
            }
        }
    }
}

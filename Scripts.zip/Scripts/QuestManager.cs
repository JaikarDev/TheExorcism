using UnityEngine;
using UnityEngine.UI;

public class QuestManager : MonoBehaviour
{
    public Text questText; // UI Text to display current quests
    public GameObject popupCanvas; // Popup Canvas for displaying notifications
    private int questStage = 0; // Tracks quest progress
    private bool isQuestPopupActive = false; // Prevents multiple pop-ups
    private bool isQuestComplete = false;

    void Start()
    {
        Debug.Log("Game Started: Setting Initial Quest");
        SetQuest("Tap on Tab button to interact with Guide Map. After that, press M to turn on Matchstick and find a Matchbox to get 6 more sticks.");
    }

    public void SetQuest(string newQuest)
    {
        if (!isQuestComplete)
        {
            Debug.Log($"Updating Quest: {newQuest}");
            questText.text = newQuest;
            questText.enabled = false; // Force UI refresh
            questText.enabled = true;

            ShowPopupMessage($"Quest Updated: {newQuest}");
        }
    }

    // Fix for error CS1061: Adding UpdateQuest method
    public void UpdateQuest(string newQuest)
    {
        SetQuest(newQuest);
    }

    public void NextQuestStage()
    {
        questStage++;
        Debug.Log($"Advancing to Quest Stage: {questStage}");

        switch (questStage)
        {
            case 1:
                SetQuest("Strike a matchstick (Press M) to create light.");
                break;
            case 2:
                SetQuest("Find a matchbox to get 6 more matchsticks.");
                break;
            case 3:
                SetQuest("Find the Fuse Box and press I to turn on the power.");
                break;
            case 4:
                SetQuest("Clap twice (Press C) to turn ON the lights or once to turn OFF the lights.");
                break;
            case 5:
                SetQuest("Find the letter in the living room.");
                break;
            case 6:
                SetQuest("Find the remaining letters and keys with a voice note.");
                break;
            case 7:
                SetQuest("Now you need to find Holy Water.");
                break;
            case 8:
                SetQuest("Now you need to purify each room with Holy Water within the time limit and final key. (Hint:- The heart of the mission always lies within the shed.)");
                break;
            case 9:
                CompleteAllQuests();
                break;
            default:
                Debug.LogWarning("Undefined quest stage!");
                break;
        }
    }

    public void CompleteAllQuests()
    {
        isQuestComplete = true;
        questText.text = "Quests Completed!";
        ShowPopupMessage("Congratulations! You�ve completed all quests!");
        Debug.Log("All quests completed!");
    }

    private void ShowPopupMessage(string message)
    {
        if (popupCanvas != null)
        {
            isQuestPopupActive = true;
            Text popupText = popupCanvas.GetComponentInChildren<Text>();

            if (popupText != null)
            {
                popupText.text = message;
                popupCanvas.SetActive(true);
                Debug.Log("Popup Shown: " + message);
                Invoke("HidePopup", 3f); // Hide after 3 seconds
            }
        }
    }

    private void HidePopup()
    {
        if (popupCanvas != null)
        {
            popupCanvas.SetActive(false);
            isQuestPopupActive = false;
            Debug.Log("Popup Hidden");
        }
    }
}

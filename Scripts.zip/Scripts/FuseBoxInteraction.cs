using UnityEngine;

public class FuseBoxInteraction : MonoBehaviour
{
    public Light fuseBoxLight; // Small light on the Fuse Box
    public AudioSource powerOnSound; // Sound when power is restored
    public QuestManager questManager; // Reference to Quest Manager
    public LightManager lightManager; // Reference to LightManager (to control house lights)

    private bool isPowerOn = false; // Tracks whether the fuse box is activated

    void Start()
    {
        fuseBoxLight.enabled = false; // Ensure the Fuse Box light starts OFF
        if (lightManager != null)
        {
            lightManager.ToggleLights(false); // Turn off all house lights at game start
        }
    }

    void OnTriggerStay(Collider other)
    {
        // Player interacts with the Fuse Box (Press I)
        if (other.CompareTag("Player") && Input.GetKeyDown(KeyCode.I))
        {
            if (!isPowerOn)
            {
                fuseBoxLight.enabled = true; // Turn on Fuse Box light
                powerOnSound?.Play(); // Optional power-on sound
                isPowerOn = true;

                // Update the quest to guide the player
                if (questManager != null)
                {
                    questManager.SetQuest("Clap twice (Press C) to turn ON the lights or once to turn OFF the lights.");
                }
            }
        }
    }

    public void FlickerLights()
    {
        if (lightManager != null)
        {
            lightManager.FlickerForSeconds(2f); // Trigger light flicker for 2 seconds
        }
    }

    public bool GetPowerStatus()
    {
        return isPowerOn; // Allows other scripts to check if power is ON
    }
}

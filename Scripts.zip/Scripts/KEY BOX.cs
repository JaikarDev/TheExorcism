using UnityEngine;

public class KEYBOX : MonoBehaviour
{
    public QuestManager questManager; // Reference to QuestManager
    private bool questUpdated = false; // Ensure quest updates only once

    void Start()
    {
        if (questManager == null)
        {
            questManager = FindObjectOfType<QuestManager>(); // Auto-find QuestManager if not set
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !questUpdated) // Ensure only the player triggers it once
        {
            Debug.Log("Player entered the quest zone. Updating quest...");

            if (questManager != null)
            {
                questManager.UpdateQuest("Now you need to purify each room with Holy Water within the time limit and final key. (Hint:- The heart of the mission always lies within the shed.)");
                questUpdated = true; // Mark quest as updated
                GetComponent<Collider>().enabled = false; // Disable this BoxCollider after quest updates
            }
            else
            {
                Debug.LogError("QuestManager not assigned or found!");
            }
        }
    }
}

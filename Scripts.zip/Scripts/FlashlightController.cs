using UnityEngine;

public class FlashlightController : MonoBehaviour
{
    private Light flashlight; // Reference to the flashlight light component
    private AudioSource audioSource; // Reference for audio feedback

    public AudioClip flashlightOnSound;  // Sound for turning the flashlight on
    public AudioClip flashlightOffSound; // Sound for turning the flashlight off
    public QuestManager questManager;    // Reference to the QuestManager
    private bool isFlashlightQuestCompleted = false; // To track if the quest is already completed

    public float mouseSensitivity = 2f; // Sensitivity for mouse movement
    public Transform flashlightPivot; // Transform to pivot the flashlight (e.g., player camera)

    private float xRotation = 0f; // For vertical rotation restriction

    void Start()
    {
        flashlight = GetComponent<Light>();
        flashlight.enabled = false;  // Flashlight is off by default

        audioSource = GetComponent<AudioSource>();

        // Automatically add an AudioSource if missing
        if (audioSource == null)
        {
            Debug.LogWarning("AudioSource component missing. Adding one automatically.");
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        // Lock the cursor to the center of the screen
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        HandleMouseLook(); // Handle mouse movement for flashlight

        if (Input.GetKeyDown(KeyCode.F)) // Toggle flashlight with F key
        {
            flashlight.enabled = !flashlight.enabled; // Toggle flashlight state

            // Play the appropriate sound effect
            if (flashlight.enabled && flashlightOnSound != null)
            {
                audioSource.PlayOneShot(flashlightOnSound);

                // Progress quest only if it hasn�t already been completed
                if (!isFlashlightQuestCompleted && questManager != null)
                {
                    questManager.NextQuestStage(); // Advance to the next quest stage
                    isFlashlightQuestCompleted = true; // Mark quest as completed
                }
            }
            else if (!flashlight.enabled && flashlightOffSound != null)
            {
                audioSource.PlayOneShot(flashlightOffSound);
            }
        }
    }

    private void HandleMouseLook()
    {
        // Get mouse input
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        // Adjust vertical rotation and clamp it
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Restrict vertical look angle

        // Apply rotation to the flashlight pivot
        flashlightPivot.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        transform.parent.Rotate(Vector3.up * mouseX); // Rotate horizontally
    }
}

using UnityEngine;

public class MusicBoxInteraction : MonoBehaviour
{
    public AudioSource musicBoxAudio; // The audio source for the music box
    public GameObject interactionPopup; // UI prompt like "Press T to toggle music"
    private bool isPlayerNearby = false; // Tracks if the player is near
    private bool isMusicPlaying = false; // Custom flag to track music state
    private PlayerMovement playerMovement; // Reference to the player's movement script

    private void Start()
    {
        if (interactionPopup != null)
        {
            interactionPopup.SetActive(false); // Hide the UI prompt initially
        }

        // Find the PlayerMovement component on the player
        playerMovement = FindObjectOfType<PlayerMovement>();
        if (playerMovement == null)
        {
            Debug.LogError("PlayerMovement script not found on the player!");
        }

        // Check if musicBoxAudio is assigned
        if (musicBoxAudio == null)
        {
            Debug.LogError("AudioSource is not assigned to the Music Box!");
        }
    }

    private void Update()
    {
        // Check if the player is nearby and presses the "T" key
        if (isPlayerNearby && Input.GetKeyDown(KeyCode.T))
        {
            if (isMusicPlaying)
            {
                TurnOffMusic();
            }
            else
            {
                TurnOnMusic();
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) // Make sure the collider is detecting the Player
        {
            isPlayerNearby = true;

            if (interactionPopup != null)
            {
                interactionPopup.SetActive(true); // Show the interaction prompt
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerNearby = false;

            if (interactionPopup != null)
            {
                interactionPopup.SetActive(false); // Hide the interaction prompt
            }
        }
    }

    private void TurnOnMusic()
    {
        if (musicBoxAudio != null)
        {
            musicBoxAudio.Play();
            isMusicPlaying = true;
            Debug.Log("Music Box: Music turned ON");

            // Lock the player's movement
            if (playerMovement != null)
            {
                playerMovement.LockMovement();
            }
        }
        else
        {
            Debug.LogError("AudioSource is not assigned!");
        }
    }

    private void TurnOffMusic()
    {
        if (musicBoxAudio != null)
        {
            musicBoxAudio.Pause();
            isMusicPlaying = false;
            Debug.Log("Music Box: Music turned OFF");

            // Unlock the player's movement
            if (playerMovement != null)
            {
                playerMovement.UnlockMovement();
            }
        }
        else
        {
            Debug.LogError("AudioSource is not assigned!");
        }
    }
}

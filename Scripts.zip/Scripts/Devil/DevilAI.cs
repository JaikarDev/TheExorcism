using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class DevilAI : MonoBehaviour
{
    public Light[] houseLights; // Lights in the room
    public AudioSource jumpScareAudio; // Scare sound
    public GameObject jumpScareVisual; // Jump scare effect
    public AudioSource eerieMusic; // Background horror music
    public Transform[] roamPoints; // Roaming positions
    public Transform windowPosition; // Window location for appearance
    public GameObject devilCharacter; // Devil�s visual
    public AudioSource whisperingSound; // Creepy whispering sound
    public AudioSource chaseSound; // Chase sound effect
    public GameObject[] floatingObjects; // Objects that float
    public float floatHeight = 2f; // How high objects float
    public float floatSpeed = 1.5f; // Speed of floating effect
    public float roamInterval = 10f; // Time between roaming
    public float angryRoamSpeed = 8f; // Speed when angry
    public float patrolSpeed = 2f; // Speed during normal patrol

    private bool isVisible = false;
    private bool isAngry = false;
    private bool isPurifying = false;
    private NavMeshAgent agent;

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        if (agent == null)
        {
            Debug.LogError("NavMeshAgent is missing!");
            return;
        }

        if (roamPoints.Length == 0)
        {
            Debug.LogWarning("No roam points set!");
        }

        StartCoroutine(Patrol()); // Begin patrolling
    }

    private void Update()
    {
        if (isAngry && !isPurifying)
        {
            StartCoroutine(RandomRoaming());
        }
    }

    public void FuseBoxTriggered()
    {
        StartCoroutine(DevilWindowAppearance());
    }

    private IEnumerator DevilWindowAppearance()
    {
        if (devilCharacter != null && windowPosition != null)
        {
            devilCharacter.transform.position = windowPosition.position;
            devilCharacter.SetActive(true);
            yield return new WaitForSeconds(2f);
            devilCharacter.SetActive(false);
        }
        else
        {
            Debug.LogWarning("DevilCharacter or WindowPosition is not assigned!");
        }
    }

    public void TriggerJumpScare()
    {
        if (!isVisible)
        {
            StartCoroutine(JumpScareRoutine());
        }
    }

    private IEnumerator JumpScareRoutine()
    {
        isVisible = true;
        if (jumpScareAudio != null) jumpScareAudio.Play();
        if (eerieMusic != null && !eerieMusic.isPlaying) eerieMusic.Play();
        if (jumpScareVisual != null) jumpScareVisual.SetActive(true);

        FlickerLights(Color.red);
        yield return new WaitForSeconds(1f);

        if (jumpScareVisual != null) jumpScareVisual.SetActive(false);
        isVisible = false;
    }

    public void HolyWaterCollected()
    {
        isAngry = true;
        isPurifying = false;
        StartCoroutine(StartPurificationSequence());
    }

    private IEnumerator StartPurificationSequence()
    {
        agent.speed = angryRoamSpeed;
        if (chaseSound != null) chaseSound.Play();
        if (whisperingSound != null) whisperingSound.Play();

        while (isAngry)
        {
            FlickerLights(Color.red);
            StartCoroutine(FloatObjects(true));

            yield return new WaitForSeconds(Random.Range(1f, 3f));
        }
    }

    public void HolyWaterUsed()
    {
        StartCoroutine(PurificationSequence());
    }

    private IEnumerator PurificationSequence()
    {
        isPurifying = true;
        isAngry = false;

        if (chaseSound != null) chaseSound.Stop();
        if (whisperingSound != null) whisperingSound.Stop();

        // Final Purification Scene
        FlickerLights(Color.white);
        yield return new WaitForSeconds(3f);

        // Lights go OFF permanently
        TurnOffLights();

        // Objects float one last time
        yield return StartCoroutine(FloatObjects(true));
        yield return new WaitForSeconds(5f);

        // Devil disappears
        if (devilCharacter != null) devilCharacter.SetActive(false);
    }

    private void FlickerLights(Color color)
    {
        foreach (Light light in houseLights)
        {
            if (light != null)
            {
                light.color = color;
                light.enabled = !light.enabled;
            }
        }
        StartCoroutine(RestoreLights());
    }

    private IEnumerator RestoreLights()
    {
        yield return new WaitForSeconds(0.5f);
        foreach (Light light in houseLights)
        {
            if (light != null)
            {
                light.enabled = true;
            }
        }
    }

    private void TurnOffLights()
    {
        foreach (Light light in houseLights)
        {
            if (light != null)
            {
                light.enabled = false;
            }
        }
    }

    private IEnumerator FloatObjects(bool enableFloating)
    {
        float timer = 0f;
        while (timer < 3f)
        {
            foreach (GameObject obj in floatingObjects)
            {
                if (obj != null)
                {
                    float yPos = enableFloating ? Mathf.Sin(Time.time * floatSpeed) * floatHeight : 0;
                    obj.transform.position = new Vector3(obj.transform.position.x, yPos, obj.transform.position.z);
                }
            }
            timer += Time.deltaTime;
            yield return null;
        }
    }

    private IEnumerator RandomRoaming()
    {
        while (isAngry)
        {
            if (roamPoints.Length > 0)
            {
                agent.SetDestination(roamPoints[Random.Range(0, roamPoints.Length)].position);
                yield return new WaitForSeconds(roamInterval);
            }
            else
            {
                Debug.LogWarning("No roaming points available for RandomRoaming!");
                yield break;
            }
        }
    }

    private IEnumerator Patrol()
    {
        int currentPoint = 0;
        while (roamPoints.Length > 0)
        {
            agent.speed = patrolSpeed;
            agent.SetDestination(roamPoints[currentPoint].position);
            while (Vector3.Distance(transform.position, roamPoints[currentPoint].position) > 1f)
            {
                yield return null;
            }
            currentPoint = (currentPoint + 1) % roamPoints.Length;
            yield return new WaitForSeconds(2f);
        }
        Debug.LogWarning("No patrol points available!");
    }
}
using UnityEngine;

public class MainDoor : MonoBehaviour
{
    public FuseBoxInteraction fuseBox; // Reference to the FuseBoxInteraction script
    public PlayerMovement playerMovement; // Reference to the PlayerMovement script
    private bool playerEntered = false; // Tracks if the player has entered the house

    private BoxCollider doorCollider;

    void Start()
    {
        doorCollider = GetComponent<BoxCollider>();
        LockDoor(); // Ensure the door starts locked
    }

    void Update()
    {
        // Unlock the door only if the fuse box is on and the player hasn't entered yet
        if (fuseBox != null && fuseBox.GetPowerStatus() && !playerEntered)
        {
            UnlockDoor();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (fuseBox != null && !fuseBox.GetPowerStatus())
            {
                Debug.Log("Door is LOCKED. Turn on the fuse box first.");
            }
        }
    }

    // Method to lock the door
    public void LockDoor()
    {
        doorCollider.isTrigger = false; // Block movement
    }

    // Method to unlock the door
    public void UnlockDoor()
    {
        if (!playerEntered) // Ensure the player hasn't entered yet
        {
            doorCollider.isTrigger = true; // Allow movement
        }
    }

    // Method to set playerEntered value
    public void SetPlayerEntered(bool entered)
    {
        playerEntered = entered;
        if (playerEntered)
        {
            LockDoor(); // Lock the door once the player enters
        }
    }
}
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IntroScript : MonoBehaviour
{
    public VideoPlayer videoPlayer;  // Assign VideoPlayer in Inspector
    public Button continueButton;    // Assign Continue Button in Inspector
    public Texture2D customCursor;   // Assign Custom Cursor in Inspector

    void Start()
    {
        continueButton.gameObject.SetActive(false);  // Hide the button initially
        videoPlayer.loopPointReached += OnVideoEnd;  // Subscribe to video end event

        // Hide cursor during video playback
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    void OnVideoEnd(VideoPlayer vp)
    {
        continueButton.gameObject.SetActive(true);  // Show the button when video ends

        // Apply the custom cursor
        Cursor.SetCursor(customCursor, Vector2.zero, CursorMode.Auto);

        // Make cursor visible
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
    }

    public void LoadGameScene()
    {
        // Hide cursor when entering the game
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        SceneManager.LoadScene("The Game");  // Change to your game scene name
    }
}

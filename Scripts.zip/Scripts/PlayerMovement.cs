using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 2f;       // Default movement speed
    public float sprintSpeed = 5f;    // Sprinting speed
    public float jumpHeight = 3f;     // Jump height
    public float mouseSensitivity = 2.5f; // Mouse sensitivity

    private Rigidbody rb;
    private float verticalRotation = 0f; // Keeps track of up/down rotation
    public Camera playerCamera;
    private bool isGrounded = true;     // Check if the player is on the ground
    private bool canMove = true;        // Determines if the player can move

    private float sprintTimer = 0f;     // Timer to track sprint duration
    private float cooldownTimer = 0f;  // Timer to track cooldown duration
    private bool isSprinting = false;   // Flag to check if the player is sprinting
    private bool canSprint = true;      // Flag to check if sprinting is allowed

    public AudioClip walkSound;  // Walk sound clip
    public AudioClip runSound;   // Run sound clip
    private AudioSource audioSource; // AudioSource to play sounds

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true; // Prevent unintended rotations caused by collisions
        Cursor.lockState = CursorLockMode.Locked;  // Lock mouse cursor
        Cursor.visible = false;  // Hide mouse cursor

        audioSource = GetComponent<AudioSource>(); // Get the AudioSource component
    }

    void Update()
    {
        if (canMove) // Only allow movement and mouse look when canMove is true
        {
            HandleMouseLook();
            HandleJump();
            HandleSprintCooldown();
            HandleWalkingAndRunningSounds(); // Handle sound based on movement
        }

        // Increment cooldown timer if sprint is on cooldown
        if (!canSprint)
        {
            cooldownTimer += Time.deltaTime;
            if (cooldownTimer >= 10f) // 10-second cooldown
            {
                canSprint = true; // Allow sprinting again
                cooldownTimer = 0f; // Reset cooldown timer
            }
        }
    }

    void FixedUpdate()
    {
        if (canMove) // Only handle movement when canMove is true
        {
            HandleMovement();
        }
    }

    private void HandleMovement()
    {
        float horizontal = Input.GetAxis("Horizontal");  // A/D
        float vertical = Input.GetAxis("Vertical");      // W/S

        // Determine current speed based on sprinting status
        float currentSpeed = isSprinting ? sprintSpeed : moveSpeed;

        // Calculate movement direction relative to where the player is facing
        Vector3 movement = transform.forward * vertical + transform.right * horizontal;

        // Apply the movement to the Rigidbody
        rb.MovePosition(rb.position + movement * currentSpeed * Time.fixedDeltaTime);
    }

    private void HandleMouseLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

        // Rotate player horizontally (left/right)
        transform.Rotate(Vector3.up * mouseX);

        // Rotate camera vertically (up/down)
        verticalRotation -= mouseY;
        verticalRotation = Mathf.Clamp(verticalRotation, -90f, 90f); // Prevent upside-down view
        playerCamera.transform.localRotation = Quaternion.Euler(verticalRotation, 0f, 0f);
    }

    private void HandleJump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            // Calculate the exact jump velocity needed to reach the desired height
            float jumpVelocity = Mathf.Sqrt(2 * jumpHeight * Physics.gravity.magnitude);
            rb.velocity = new Vector3(rb.velocity.x, jumpVelocity, rb.velocity.z);
            isGrounded = false; // Player is airborne
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        // Check if the player landed back on the ground
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    // Handle Sprinting and Cooldown
    private void HandleSprintCooldown()
    {
        // Check if the player wants to sprint and sprinting is allowed
        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKey(KeyCode.W) && canSprint)
        {
            if (!isSprinting) // Start sprinting
            {
                isSprinting = true;
                sprintTimer = 0f; // Reset sprint timer
            }
        }

        // If sprinting, increment sprint timer
        if (isSprinting)
        {
            sprintTimer += Time.deltaTime;
            if (sprintTimer >= 3f) // Stop sprinting after 3 seconds
            {
                isSprinting = false;
                canSprint = false; // Begin cooldown
            }
        }
    }

    // Play walk/run sound based on movement
    private void HandleWalkingAndRunningSounds()
    {
        if (audioSource == null) return; // Skip sound handling if there's no AudioSource

        // Check if the player is moving (either horizontally or vertically)
        bool isMoving = Mathf.Abs(Input.GetAxis("Horizontal")) > 0.1f || Mathf.Abs(Input.GetAxis("Vertical")) > 0.1f;

        // If the player is moving, handle the sounds
        if (isMoving)
        {
            if (isSprinting && !audioSource.isPlaying) // Play run sound if sprinting
            {
                audioSource.clip = runSound;
                audioSource.Play();
            }
            else if (!isSprinting && !audioSource.isPlaying) // Play walk sound if not sprinting
            {
                audioSource.clip = walkSound;
                audioSource.Play();
            }
        }
        else
        {
            // Stop the sound when the player is not moving
            if (audioSource.isPlaying)
            {
                audioSource.Stop();
            }
        }
    }

    // Lock and Unlock Movement (for interaction or cutscenes)
    public void LockMovement()
    {
        canMove = false; // Disable movement and mouse look
        rb.isKinematic = true; // Freeze Rigidbody to ensure complete stoppage
    }

    public void UnlockMovement()
    {
        canMove = true; // Enable movement and mouse look
        rb.isKinematic = false; // Return Rigidbody to normal state
    }
}
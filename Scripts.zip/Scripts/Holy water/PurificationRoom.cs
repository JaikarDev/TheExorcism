﻿using UnityEngine;

public class PurificationRoom : MonoBehaviour
{
    public AudioClip screamSound; // Scream sound on purification
    public AudioClip lightBlastSound; // Light explosion sound
    public Light roomLight; // Light that will be turned off

    private bool purified = false; // Track if the room is purified

    private void Update()
    {
        // ✅ Player must be close & press 'F' to purify
        if (!purified && Input.GetKeyDown(KeyCode.F) && IsPlayerNearby())
        {
            PurifyRoom();
        }
    }

    private void PurifyRoom()
    {
        if (purified) return; // ✅ Prevent multiple purifications

        if (GameManager.instance != null && GameManager.instance.HasHolyWater()) // ✅ Check if Holy Water was collected
        {
            purified = true;
            GameManager.instance.AddPurification(); // ✅ Add purification count

            // ✅ Play scream sound (if assigned)
            if (screamSound != null)
            {
                AudioSource.PlayClipAtPoint(screamSound, transform.position, 1.0f);
            }

            // ✅ Play light blast sound (if assigned)
            if (lightBlastSound != null)
            {
                AudioSource.PlayClipAtPoint(lightBlastSound, transform.position, 1.0f);
            }

            // ✅ Turn off room light (if assigned)
            if (roomLight != null)
            {
                roomLight.enabled = false;
            }

            // ✅ If you want to consume Holy Water after purification, uncomment this:
            // GameManager.instance.UseHolyWater(); 
        }
    }

    private bool IsPlayerNearby()
    {
        Collider[] colliders = Physics.OverlapSphere(transform.position, 2f);
        foreach (Collider collider in colliders)
        {
            if (collider.CompareTag("Player"))
            {
                return true;
            }
        }
        return false;
    }
}

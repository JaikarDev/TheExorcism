﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public float timer = 0f;
    private bool timerRunning = false;
    public int totalPurificationRooms = 9;
    private int purifiedRooms = 0;
    private bool hasHolyWater = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void StartTimer(float duration)
    {
        timer = duration;
        timerRunning = true;
    }

    void Update()
    {
        if (timerRunning && timer > 0)
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                timerRunning = false;
                HandleTimeOut();
            }
        }
    }

    public void CollectHolyWater()
    {
        hasHolyWater = true;
    }

    public bool HasHolyWater()
    {
        return hasHolyWater;
    }

    public void AddPurification()
    {
        if (hasHolyWater)
        {
            purifiedRooms++;
            timer += 1f;

            if (purifiedRooms >= totalPurificationRooms)
            {
                HandleGoodEnding();
            }
        }
    }

    void HandleTimeOut()
    {
        if (purifiedRooms > 0)
        {
            HandleNeutralEnding();
        }
        else
        {
            HandleBadEnding();
        }
    }

    void HandleBadEnding()
    {
        Debug.Log("Bad Ending: Player collected Holy Water but left without purifying.");
        SceneManager.LoadScene("Bad Ending Scene");
    }

    void HandleNeutralEnding()
    {
        Debug.Log("Neutral Ending: Player ran out of time before completing purification.");
        SceneManager.LoadScene("Neutral Ending Scene");
    }

    void HandleGoodEnding()
    {
        Debug.Log("Good Ending: Player successfully purified the house in time!");
        SceneManager.LoadScene("Good Ending Scene");
    }

    public void CheckExitCondition()
    {
        if (hasHolyWater)
        {
            if (purifiedRooms == totalPurificationRooms && timer > 0)
            {
                HandleGoodEnding();
            }
            else if (timer <= 0)
            {
                HandleNeutralEnding();
            }
            else
            {
                HandleBadEnding();
            }
        }
    }
}

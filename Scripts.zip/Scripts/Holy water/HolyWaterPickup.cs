﻿using UnityEngine;
using System.Collections;

public class HolyWaterPickup : MonoBehaviour
{
    public GameObject[] purificationRooms; // Stores all purification rooms
    public AudioClip whisperSound; // Sound when picking up Holy Water
    public float flickerDuration = 5f; // Duration of light flicker
    public Light[] lights; // All lights in the scene
    public float timerDuration = 30f; // Initial timer duration

    private bool isCollected = false; // Track if Holy Water is collected
    private bool canPickup = false; // Check if player is in range

    private void Start()
    {
        // Find all purification rooms and disable them at the start
        purificationRooms = GameObject.FindGameObjectsWithTag("PurificationRoom");
        foreach (GameObject room in purificationRooms)
        {
            room.SetActive(false); // Disable all purification rooms
        }
    }

    private void Update()
    {
        // Player must be close and press 'E' to collect Holy Water
        if (!isCollected && canPickup && Input.GetKeyDown(KeyCode.E))
        {
            CollectHolyWater();
        }
    }

    private void CollectHolyWater()
    {
        isCollected = true;
        GameManager.instance.CollectHolyWater(); // ✅ Register in GameManager

        // Play whisper sound at Holy Water location
        if (whisperSound != null)
        {
            AudioSource.PlayClipAtPoint(whisperSound, transform.position);
        }

        // Start flickering effect
        StartCoroutine(FlickerLights());

        // Enable all purification rooms
        foreach (GameObject room in purificationRooms)
        {
            room.SetActive(true);
        }

        // Start the timer
        GameManager.instance.StartTimer(timerDuration);

        // Destroy the Holy Water object after pickup
        Destroy(gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canPickup = true; // Player is in range to pick up Holy Water
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canPickup = false; // Player left, can't pick up
        }
    }

    IEnumerator FlickerLights()
    {
        float elapsedTime = 0f;
        while (elapsedTime < flickerDuration)
        {
            foreach (Light light in lights)
            {
                light.enabled = !light.enabled; // Toggle lights on and off
            }
            yield return new WaitForSeconds(0.2f); // Small delay for flickering effect
            elapsedTime += 0.2f;
        }

        // Ensure all lights remain on after flickering
        foreach (Light light in lights)
        {
            light.enabled = true;
        }
    }

    public bool IsCollected()
    {
        return isCollected;
    }
}

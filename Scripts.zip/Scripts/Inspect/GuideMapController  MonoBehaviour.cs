using UnityEngine;
using UnityEngine.UI;

public class GuideMapController : MonoBehaviour
{
    [Header("Guide Map Settings")]
    public GameObject guideMapUI; // Assign Guide Map UI Panel
    public Image guideMapImage; // Assign UI Image inside the Guide Map UI
    public Sprite defaultMap; // Default map sprite
    public Sprite strikeMap; // Map with strike-through collected items

    [Header("Audio Settings")]
    public AudioClip openCloseSound; // Sound when opening/closing
    private AudioSource audioSource;

    private bool isMapOpen = false; // Track if map is open
    private bool hasCollectedAllItems = false; // Track item collection

    // Reference to the QuestManager UI
    public GameObject questManagerUI;

    // Additional tracking for specific items
    private bool fuseBoxInteracted = false;
    private bool matchBoxCollected = false;
    private bool lettersInteracted = false;
    private bool audioInteracted = false;
    private bool keysCollected = false;
    private bool holyWaterCollected = false;

    void Start()
    {
        // Assign audio source component
        audioSource = gameObject.AddComponent<AudioSource>();

        // Hide Guide Map at the start
        guideMapUI.SetActive(false);
    }

    void Update()
    {
        // Press Tab to toggle the Guide Map
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            ToggleGuideMap();
        }
    }

    public void ToggleGuideMap()
    {
        isMapOpen = !isMapOpen; // Toggle the map state
        guideMapUI.SetActive(isMapOpen); // Show or Hide the map UI

        // Enable/Disable Quest Manager UI when the map is toggled
        if (questManagerUI != null)
        {
            questManagerUI.SetActive(!isMapOpen);
        }

        // Play opening/closing sound
        if (openCloseSound != null)
        {
            audioSource.PlayOneShot(openCloseSound);
        }

        // Change the sprite if all items are collected
        guideMapImage.sprite = hasCollectedAllItems ? strikeMap : defaultMap;
    }

    // Method to update the map when all items are collected
    public void MarkItemsCollected()
    {
        hasCollectedAllItems = true;
    }

    // Methods to mark individual items as interacted or collected
    public void InteractFuseBox() { fuseBoxInteracted = true; CheckAllItemsCollected(); }
    public void CollectMatchBox() { matchBoxCollected = true; CheckAllItemsCollected(); }
    public void InteractLetters() { lettersInteracted = true; CheckAllItemsCollected(); }
    public void InteractAudio() { audioInteracted = true; CheckAllItemsCollected(); }
    public void CollectKeys() { keysCollected = true; CheckAllItemsCollected(); }
    public void CollectHolyWater() { holyWaterCollected = true; CheckAllItemsCollected(); }

    // Check if all necessary items are collected/interacted
    private void CheckAllItemsCollected()
    {
        if (fuseBoxInteracted && matchBoxCollected && lettersInteracted && audioInteracted && keysCollected && holyWaterCollected)
        {
            MarkItemsCollected();
        }
    }
}

using UnityEngine;

public class MatchboxPickup : MonoBehaviour
{
    public string matchboxName = "Matchbox"; // Name for debug purposes
    public AudioSource pickupSound; // Optional pickup sound
    public QuestManager questManager; // Reference to Quest Manager
    public MatchboxController matchboxController; // Reference to MatchboxController

    private bool isCollected = false; // Prevents multiple pickups

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !isCollected)
        {
            CollectMatchbox();
        }
        // Update the quest to guide the player
        if (questManager != null)
        {
            questManager.SetQuest("Find the Fuse Box and press I to turn on the power.");
        }
    }

    private void CollectMatchbox()
    {
        isCollected = true;

        // Give matchsticks to the player
        if (matchboxController != null)
        {
            matchboxController.CollectMatchbox();
            Debug.Log($"{matchboxName} collected! Matchsticks added.");
        }

        // Play pickup sound if available
        if (pickupSound != null)
        {
            pickupSound.Play();
        }

        // Destroy the matchbox after collection
        Destroy(gameObject);
    }
}

using UnityEngine;
using System.Collections;

public class LightManager : MonoBehaviour
{
    public Light[] houseLights; // Assign all house lights in the Inspector

    void Start()
    {
        ToggleLights(false); // Turn off all lights at the start of the game
    }

    public void ToggleLights(bool turnOn)
    {
        foreach (Light light in houseLights)
        {
            light.enabled = turnOn;
        }
    }

    public void FlickerForSeconds(float duration)
    {
        StartCoroutine(FlickerLightsCoroutine(duration));
    }

    private IEnumerator FlickerLightsCoroutine(float duration)
    {
        float elapsedTime = 0f;
        while (elapsedTime < duration)
        {
            // Toggle lights ON and OFF
            bool isOn = Random.value > 0.5f; // Randomize ON/OFF state
            foreach (Light light in houseLights)
            {
                light.enabled = isOn;
            }

            elapsedTime += 0.1f; // Adjust flicker speed
            yield return new WaitForSeconds(0.1f); // Wait between flickers
        }

        // Ensure all lights are ON after flickering
        ToggleLights(true);
    }
}
